package org.example.Taks;

import io.restassured.http.ContentType;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.rest.interactions.Post;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class PostSaleProduct implements Task {
    private final String title, price, description, category, image;

    public PostSaleProduct(String title, String price, String description, String category, String image) {
        this.title = title;
        this.price = price;
        this.description = description;
        this.category = category;
        this.image = image;
    }

    public static Performable withDetails(String title, String price, String description, String category, String image) {
        return instrumented(PostSaleProduct.class, title, price, description, category, image);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Post.to("/products")
                        .with(requestSpecification -> requestSpecification
                                .contentType(ContentType.JSON)
                                .header("Accept", "application/json")
                                .body("""
                                        {
                                            "title": "%s",
                                            "price": %s,
                                            "description": "%s",
                                            "image": "%s",
                                            "category": "%s"
                                        }""".formatted(title, price, description, image, category))
                                .log().all())
        );

        SerenityRest.lastResponse().body().prettyPrint();
        Object createdId = SerenityRest.lastResponse().path("id");
        if (createdId != null) {
            String productId = createdId.toString();
            OnStage.theActorInTheSpotlight().remember("productId", productId);
            System.out.println("Product ID: " + productId);
        }
    }
}
