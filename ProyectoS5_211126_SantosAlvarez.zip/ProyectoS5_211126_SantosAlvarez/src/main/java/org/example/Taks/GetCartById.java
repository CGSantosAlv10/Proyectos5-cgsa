package org.example.Taks;

import io.restassured.http.ContentType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class GetCartById implements Task {
    private final String cartId;

    public GetCartById(String cartId) {
        this.cartId = cartId;
    }

    public static Performable withId(String cartId) {
        return instrumented(GetCartById.class, cartId);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Get.resource("/carts/{id}")
                        .with(requestSpecification -> requestSpecification
                                .pathParam("id", cartId)
                                .contentType(ContentType.JSON)
                                .log().all())
        );
    }
}