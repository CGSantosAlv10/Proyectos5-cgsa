package org.example.Questions;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ResponseValue implements Question<String> {
    private final String jsonPath;

    public ResponseValue(String jsonPath) {
        this.jsonPath = jsonPath;
    }

    public static Question<String> fromPath(String jsonPath) {
        return new ResponseValue(jsonPath);
    }

    @Override
    public String answeredBy(Actor actor) {
        Object value = SerenityRest.lastResponse().path(jsonPath);
        return value != null ? value.toString() : null;
    }
}