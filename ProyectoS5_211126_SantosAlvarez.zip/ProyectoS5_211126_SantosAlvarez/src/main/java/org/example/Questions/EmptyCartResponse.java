package org.example.Questions;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class EmptyCartResponse implements Question<Boolean> {

    public static EmptyCartResponse value() {
        return new EmptyCartResponse();
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        String body = SerenityRest.lastResponse().getBody().asString().trim();
        return body.isEmpty() || "null".equalsIgnoreCase(body) || "{}".equals(body);
    }
}