package org.example.StepDefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import org.example.Questions.EmptyCartResponse;
import org.example.Questions.ResponseCode;
import org.example.Taks.GetCartById;
import org.example.Taks.GetCatalogProducts;
import org.example.Taks.GetSalesCart;
import org.example.Taks.PostSaleProduct;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.CoreMatchers.equalTo;

public class SalesStepDefinition {

    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }

    @Given("el {actor} establece el endpoint de ventas")
    public void elActorEstableceElEndpointDeVentas(Actor actor) {
        actor.whoCan(CallAnApi.at("https://fakestoreapi.com"));
    }

    @When("el actor consulta todos los productos")
    public void elActorConsultaTodosLosProductos() {
        theActorInTheSpotlight().attemptsTo(GetCatalogProducts.fromEndpoint("/products"));
    }

    @When("el actor registra un producto con {string} {string} {string} {string} {string}")
    public void elActorRegistraUnProductoCon(String title, String price, String description, String category, String image) {
        theActorInTheSpotlight().attemptsTo(
                PostSaleProduct.withDetails(title, price, description, category, image)
        );
    }

    @When("el actor consulta todos los carritos")
    public void elActorConsultaTodosLosCarritos() {
        theActorInTheSpotlight().attemptsTo(GetSalesCart.fromEndpoint("/carts"));
    }

    @When("el actor consulta el carrito con id {string}")
    public void elActorConsultaElCarritoConId(String cartId) {
        theActorInTheSpotlight().attemptsTo(GetCartById.withId(cartId));
    }

    @Then("el codigo de respuesta debe ser {int}")
    public void elCodigoDeRespuestaDebeSer(int responseCode) {
        theActorInTheSpotlight().should(
                seeThat("El codigo de respuesta ", ResponseCode.getStatus(), equalTo(responseCode))
        );
    }

    @And("la respuesta del carrito debe venir vacia o nula")
    public void laRespuestaDelCarritoDebeVenirVaciaONula() {
        OnStage.theActorInTheSpotlight().should(
                seeThat("la respuesta del carrito inexistente es nula o vacia",
                        EmptyCartResponse.value(), is(true))
        );
    }
}