@Sales
Feature: Operaciones de ventas en tienda
  Como usuario del sistema de ventas
  Quiero consultar y registrar productos y carritos
  Para validar respuestas exitosas y casos de error del servicio

  Scenario: Consultar todos los productos de venta
    Given el actor establece el endpoint de ventas
    When el actor consulta todos los productos
    Then el codigo de respuesta debe ser 200

  Scenario Outline: Registrar un nuevo producto de venta
    Given el actor establece el endpoint de ventas
    When el actor registra un producto con "<title>" "<price>" "<description>" "<category>" "<image>"
    Then el codigo de respuesta debe ser 201

    Examples:
      | title       | price  | description                | category | image                      |
      | Mesa para 4 | 129.90 | Mesa cuadrada con 4 sillas | Muebles  | https://example.com/m1.png |

  Scenario: Consultar todos los carritos de venta
    Given el actor establece el endpoint de ventas
    When el actor consulta todos los carritos
    Then el codigo de respuesta debe ser 200

  Scenario: Consultar un carrito inexistente por id
    Given el actor establece el endpoint de ventas
    When el actor consulta el carrito con id "999999"
    Then el codigo de respuesta debe ser 200
    And la respuesta del carrito debe venir vacia o nula